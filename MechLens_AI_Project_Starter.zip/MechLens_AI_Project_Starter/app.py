from flask import Flask, request, jsonify, render_template
from PIL import Image
import io

app = Flask(__name__)

def analyze_image(image):
    # Demo placeholder. Replace with a Snapdragon/Qualcomm AI Hub-compatible model.
    return {
        "component": "Demo Engineering Component",
        "confidence": 0.91,
        "observation": "Image received successfully. Connect a local vision model for real inference.",
        "learning_point": "Use a domain-specific model trained on approved laboratory component images."
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/api/analyze")
def analyze():
    f = request.files.get("image")
    if not f:
        return jsonify({"error": "No image supplied"}), 400
    image = Image.open(io.BytesIO(f.read())).convert("RGB")
    return jsonify(analyze_image(image))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
