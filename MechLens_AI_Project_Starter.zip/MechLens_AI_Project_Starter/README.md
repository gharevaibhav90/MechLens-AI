# MechLens AI
On-Device Visual Lab Assistant for Engineering Students.

## Prototype
This starter is a local Flask demonstrator. It accepts an image upload and returns a placeholder result.
Replace the `analyze_image()` function with a Snapdragon/Qualcomm AI Hub-compatible vision model for the final demo.

## Run
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py

Open http://127.0.0.1:5000

## Competition positioning
- Local-first architecture
- Designed for Snapdragon-powered HP PCs
- Vision + local engineering knowledge
- Educational demonstrator, not certified industrial diagnosis
